from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Subject, Result
admin.site.register(Subject)
admin.site.register(Result)